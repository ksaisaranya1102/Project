---
title: Face Recognition SDK
emoji: ⚡
colorFrom: yellow
colorTo: pink
sdk: docker
pinned: false
license: mit
---

Check out the configuration reference at https://huggingface.co/spaces/SaiSaranya/Face-Recognition
