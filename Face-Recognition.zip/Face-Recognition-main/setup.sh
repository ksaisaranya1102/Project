#!/bin/bash
sudo apt-get update
sudo apt-get install -y libgl1-mesa-glx libsm6 libxrender1 libxext6
